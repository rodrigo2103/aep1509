package observer;

import javax.swing.JOptionPane;

public class App {
	
	public static void main(String[] args) {
		
		Pasta p1 = new Pasta("728b2");
		Pasta p2 = new Pasta("123x4");
		
		p2.setListener(new PastaListener() {
			@Override
			public void pastaFoiAberta(int combinacao, String botaoParaAbrir) {
				JOptionPane.showMessageDialog(null, "A Pasta foi aberta com o " 
			           + botaoParaAbrir 
			           + " e a combinacao " 
			           + combinacao);
			}			
		});
		
		p1.abrir(123456);
		p2.abrir(987135);
	}
}
