package observer;

public interface PastaListener {
	
	void pastaFoiAberta(int combinacao, String botaoParaAbrir);

}
