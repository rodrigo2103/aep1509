package observer;

public class Pasta {

	private String botaoParaAbrir;
	private PastaListener listener;

	public Pasta(String botaoParaAbrir) {
		this.botaoParaAbrir = botaoParaAbrir;
	}

	public void setListener(PastaListener listener) {
		this.listener = listener;
		
	}

	public void abrir(int combinacao) {
		if (listener != null) {
			listener.pastaFoiAberta(combinacao, botaoParaAbrir);
		}
		
	}

}
