package builder;

public class Individuo {

	public Individuo setApelido(String apelido) {
		return this;
	}

	public Individuo setNomereal(String nomereal) {
		return this;
	}

	public Individuo setCPF(int cpf) {
		return this;
	}

}
