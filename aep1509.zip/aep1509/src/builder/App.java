package builder;

public class App {
	
	public static void main(String[] args) {
		
		Casa nosso = Casa.builder()
				.estilo(Estilo.ANTIGO)
				.cor(Cor.TRANSPARENTE)
				.build();
		
		System.out.println(nosso.getEstilo());
		System.out.println(nosso.getCor());



		Individuo i = new Individuo();
		i.setApelido("construtor").setNomereal("Rogerio").setCPF(535874769);
		
		
	}

}
