package builder;

public enum Estilo {
	ANTIGO
}
