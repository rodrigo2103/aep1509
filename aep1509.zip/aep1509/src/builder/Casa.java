package builder;

public class Casa {
	public Estilo estilo;
	private Cor cor;

	private Casa() {
		
	}
	
	public Estilo getEstilo() {
		return estilo;
	}
	public Cor getCor() {
		return cor;
	}	
	public static CasaBuilder builder() {
		return new CasaBuilder();
	}


	
	
	static class CasaBuilder {
		private Estilo estilo;
		private Cor cor;

		public CasaBuilder estilo(Estilo estilo) {
			this.estilo = estilo;
			return this;
		}

		public CasaBuilder cor(Cor cor) {
			this.cor = cor;
			return this;
		}

		public Casa build() {
			Casa nova = new Casa();
			if (this.estilo != null) {
				nova.estilo = this.estilo;
			}
			if (this.cor != null) {
				nova.cor = this.cor;
			}
			return nova;
		}
		
	}

}
