package builder;

public enum Cor {
	TRANSPARENTE
}