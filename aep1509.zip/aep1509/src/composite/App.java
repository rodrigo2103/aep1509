package composite;

import javax.swing.JOptionPane;



public class App {
	
	public static void main(String[] args) {
		
		Pasta p1 = new Pasta("728b2");
		Pasta p2 = new Pasta("123x4");
		
		PastaListenerComposite composite = new PastaListenerComposite();
		composite.adicionarListener(new PastaListener() {
			@Override
			public void pastaFoiAberta(int combinacao, String botaoParaAbrir) {
				JOptionPane.showMessageDialog(null, "A Pasta foi aberta com o " 
			           + botaoParaAbrir 
			           + " e a combinacao " 
			           + combinacao);
			}			
		});
		composite.adicionarListener(new CofreListener() {
			@Override
			public void pastaFoiAberto(int combinacao, String botaoParaAbrir) {
				JOptionPane.showMessageDialog(null, "A Pasta foi aberta com o " 
			           + botaoParaAbrir 
			           + " e a combinacao " 
			           + combinacao);
			}			
		});

		
		p2.setListener(composite);
		
		p1.abrir(123456);
		p2.abrir(987135);
	}
}
