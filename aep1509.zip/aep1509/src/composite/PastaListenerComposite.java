package composite;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;



public class PastaListenerComposite implements PastaListener {
	private Set<PastaListener> componentes = new HashSet<>();

	@Override
	public void pastaFoiAberta(int combinacao, String botaoParaAbrir) {
		System.out.println("Opa, chamaram o metodo do composite!");
		for (PastaListener pastaListener : componentes) {
			pastaListener.pastaFoiAberto(combinacao, botaoParaAbrir);
		}
	}

	public void adicionarListener(PastaListener listener) {
		componentes.add(listener);
	}

}
